<?php
/**
 * Plugin Name: Coco Tran Site Snippets
 * Description: The [ctt_book] booking box shortcode and the paywall / dateModified structured-data additions for Rank Math. Same code as the mu-plugins in the audit repo, packaged so it installs from Plugins → Add New → Upload.
 * Version: 1.0.0
 * Author: Coco Tran
 * Requires PHP: 8.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/booking-box-shortcode.php';
require_once __DIR__ . '/paywall-schema-snippet.php';
