<?php
/**
 * Plugin Name: Coco Tran Site Snippets
 * Description: The [ctt_book] booking box shortcode, the paywall / dateModified structured-data additions for Rank Math, ACF-field images in the Rank Math image sitemap, internal auto-linking from the library link map (/coco-tran/v1/link-map), the "Pair it with" related block and the author line + Person schema, and REST exposure of the magazine post types / taxonomies / ACF groups for the Studio Desk worker. Same code as the mu-plugins in the audit repo, packaged so it installs from Plugins → Add New → Upload.
 * Version: 1.2.5
 * Author: Coco Tran
 * Requires PHP: 8.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/booking-box-shortcode.php';
require_once __DIR__ . '/paywall-schema-snippet.php';
require_once __DIR__ . '/image-sitemap.php';
require_once __DIR__ . '/autolink.php';
require_once __DIR__ . '/pair.php';
require_once __DIR__ . '/authority.php';
require_once __DIR__ . '/rest-expose.php';
require_once __DIR__ . '/template-hooks.php';
require_once __DIR__ . '/acf-groups.php';
